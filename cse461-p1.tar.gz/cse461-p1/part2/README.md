# Lab 1 Part 2
## Members
* Wayne Huang, NetId: tzuwei37
* Vincent Wang, NetID: whwen528
* Eric Kuo, NetID: cskuo

## Usage
```
bash run_server.sh <host> <port>
e.g: bash run_server.sh attu2.cs.washington.edu 4610
```
