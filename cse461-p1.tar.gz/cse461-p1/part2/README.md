# Lab 1 Part 2
## Members
* Wayne Huang, NetId: tzuwei37
* Vincent Wang, NetID: whwen528
* Eric Kuo, NetID: cskuo

## Secret Sequences
* Secret A:
* Secret B:
* Secret C:
* Secret D:

## Usage
```
python3 server.py
```
