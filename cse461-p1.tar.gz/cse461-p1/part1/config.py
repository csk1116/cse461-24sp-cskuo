STEP = 1
STUDENT_ID = 860
BUFFER_SIZE = 4096
HEADER_FORMAT = '!IIHH' # Length, psecret, step, student_no
HEADER_LEN = 12