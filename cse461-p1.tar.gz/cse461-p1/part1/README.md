# Lab 1 Part 1
## Members
* Wayne Huang, NetId: tzuwei37
* Vincent Wang, NetID: whwen528
* Eric Kuo, NetID: cskuo

## Secret Sequences
* Secret A: 63
* Secret B: 28
* Secret C: 252
* Secret D: 320

## Usage
```
bash run_client.sh <host> <port>
e.g: bash run_client.sh attu2.cs.washington.edu 41201
```
